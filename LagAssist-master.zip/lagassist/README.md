LagAssist is a plugin that provides tools to be used to analyse, prevent and resolve lag. This sourcecode is provided as reference to licensed individuals or companies that have purchased the plugin from any of the available sources it is provided in. 
(eg: https://www.spigotmc.org/resources/lagassist-%E2%9A%A1-advanced-performance-solution-%E2%9A%A1-1-8-1-16-compatible.56399/)

The accessibility of the code doesn't grant you rights to re-distribute or share this sourcecode outside of the intended purpose.


**Code Bounty:**

Any Developers making considerable contributions to the project can receive a free license to use the plugin in commercial contexts without having to purchase it.